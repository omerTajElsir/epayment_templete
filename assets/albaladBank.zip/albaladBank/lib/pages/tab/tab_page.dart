import 'package:flutter/material.dart';
import 'package:transformer_page_view/transformer_page_view.dart';
import '../rigister/rigister_page.dart';

class TabPage extends StatefulWidget {
  @override
  _TabPageState createState() => _TabPageState();
}

class _TabPageState extends State<TabPage> {
  List<String> images = [
    'assets/tab/Onboarding-01.png',
    'assets/tab/Onboarding-02.png',
    'assets/tab/Onboarding-03.png'
  ];

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: TransformerPageView(
        loop: false,
        itemBuilder: (context, index) {
          return Container(
            height: size.height,
            width: size.width,
            decoration: BoxDecoration(
                image: DecorationImage(
              image: AssetImage(images[index]),
              fit: BoxFit.fill,
            )),
            child: Stack(
                children: images.length > index + 1
                    ? <Widget>[
                        Positioned(
                          left: 0.0,
                          bottom: 10.0,
                          child: FlatButton(
                              onPressed: () => Navigator.of(context)
                                  .pushReplacement(MaterialPageRoute(
                                      builder: (context) => RigisterPage())),
                              child: Text(
                                'Skip',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 20,
                                    color: Colors.white),
                              )),
                        ),
                        Positioned(
                          right: 0.0,
                          bottom: 10.0,
                          child: FlatButton(
                              onPressed: () {},
                              child: Text('Next',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      color: Colors.white))),
                        ),
                        Positioned(
                          right: 0.0,
                          bottom: 10.0,
                          child: FlatButton(
                              onPressed: () {},
                              child: Text('Next',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      color: Colors.white))),
                        )
                      ]
                    : <Widget>[
                        Positioned(
                          right: 0.0,
                          bottom: 10.0,
                          child: FlatButton(
                              onPressed: () => Navigator.of(context)
                                  .pushReplacement(MaterialPageRoute(
                                      builder: (context) => RigisterPage())),
                              child: Text('Signup',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      color: Colors.white))),
                        )
                      ]),
          );
        },
        itemCount: images.length,
      ),
    );
  }
}
