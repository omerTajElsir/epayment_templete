import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  var width, height;
  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width / 100;
    height = MediaQuery.of(context).size.height / 100;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: Stack(
            children: <Widget>[
              Container(
                width: width * 100,
                height: height * 100,
                child: Column(
                  children: <Widget>[
                    Container(
                      color: Color(0xff161616),
                      height: height * 33,
                    ),
                    SizedBox(
                      height: height * 9  ,
                    ),
                    Container(
                      margin: EdgeInsets.only(left: width * 8),
                      child: Align(
                          alignment: Alignment.centerLeft,
                          child: Text('GENERAL',
                            style: TextStyle(
                            color: Colors.grey[600],
                                fontWeight: FontWeight.w600,
                                fontSize: 18),)),
                    ),
                    Card(
                        margin: EdgeInsets.only(top: height * 2),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        elevation: 7,
                        child: Container(
                          width: width * 90,
                          height: height * 9,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  SizedBox(width: width* 3,),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: 50,
                                      height: height * 7,
                                      color: Color(0xffDEDFE1),
                                      child: Center(
                                        child: Icon(Icons.settings,size: 23,color: Colors.grey[600],),
                                      ),
//                                  child: Image.asset(''),
                                    ),
                                  ),
                                  SizedBox(width: width* 3,),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text(
                                        'Account Settings',
                                        style: TextStyle(
                                            color: Colors.grey[800],
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16),
                                      ),
                                      SizedBox(height: height* 1,),
                                      Text(
                                        'Update and modify your profile',
                                        style: TextStyle(
                                            color: Colors.grey[600],
                                            fontWeight: FontWeight.w600,
                                            fontSize: 14),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              Container(
                                child: Icon(Icons.keyboard_arrow_right,size: 25,color: Colors.grey[400],),
                              )


                            ],
                          ),
                        )),
                    Card(
                        margin: EdgeInsets.only(top: height * 2),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        elevation: 7,
                        child: Container(
                          width: width * 90,
                          height: height * 9,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  SizedBox(width: width* 3,),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: 50,
                                      height: height * 7,
                                      color: Color(0xffDEDFE1),
                                      child: Center(
                                        child: Icon(Icons.credit_card,size: 23,color: Colors.grey[600],),
                                      ),
//                                  child: Image.asset(''),
                                    ),
                                  ),
                                  SizedBox(width: width* 3,),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text(
                                        'Payment Details',
                                        style: TextStyle(
                                            color: Colors.grey[800],
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16),
                                      ),
                                      SizedBox(height: height* 1,),
                                      Text(
                                        'Cards Settings',
                                        style: TextStyle(
                                            color: Colors.grey[600],
                                            fontWeight: FontWeight.w600,
                                            fontSize: 14),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              Container(
                                child: Icon(Icons.keyboard_arrow_right,size: 35,color: Colors.grey[400],),
                              )


                            ],
                          ),
                        )),
                    Card(
                        margin: EdgeInsets.only(top: height * 2),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        elevation: 7,
                        child: Container(
                          width: width * 90,
                          height: height * 9,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: <Widget>[
                                  SizedBox(width: width* 3,),
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Container(
                                      width: 50,
                                      height: height * 7,
                                      color: Color(0xffDEDFE1),
                                      child: Center(
                                        child: Icon(Icons.notifications,size: 25,color: Colors.grey[600],),
                                      ),
//                                  child: Image.asset(''),
                                    ),
                                  ),
                                  SizedBox(width: width* 3,),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Text(
                                        'App Settings',
                                        style: TextStyle(
                                            color: Colors.grey[800],
                                            fontWeight: FontWeight.w600,
                                            fontSize: 16),
                                      ),
                                      SizedBox(height: height* 1,),
                                      Text(
                                        'Notifications & Alerts',
                                        style: TextStyle(
                                            color: Colors.grey[600],
                                            fontWeight: FontWeight.w600,
                                            fontSize: 14),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                              Container(
                                child: Icon(Icons.keyboard_arrow_right,size: 35,color: Colors.grey[400],),
                              )


                            ],
                          ),
                        )),
                  ],
                ),
              ),
              Container(
                color: Color(0xff161616),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      child: Row(
                        children: <Widget>[
                          Container(
                              margin: EdgeInsets.only(top: 3),
                              child: IconButton(
                                  icon: Icon(
                                    Icons.arrow_back_ios,
                                    size: 20,
                                    color: Colors.grey[100],
                                  ),
                                  onPressed: null)),
                          Container(
                              margin: EdgeInsets.only(top: 5),
                              child: Text(
                                'Profile',
                                style: TextStyle(
                                    color: Colors.grey[100],
                                    fontSize: 20,
                                    fontWeight: FontWeight.w600),
                              ))
                        ],
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.only(top: 3),
                        child: IconButton(
                            icon: Icon(
                              Icons.menu,
                              size: 25,
                              color: Colors.grey[100],
                            ),
                            onPressed: null)),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Card(
                    margin: EdgeInsets.only(top: height * 13),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    elevation: 7,
                    child: Container(
                      width: width * 83,
                      height: height * 26,
                      child: Center(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            SizedBox(
                              height: height * 0,
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: Container(
                                width: 90,
                                height: 100,
                                color: Colors.blueGrey,
//                                  child: Image.asset(''),
                              ),
                            ),
                            SizedBox(
                              height: height * 2,
                            ),
                            Text(
                              'Ahmed ALbasha',
                              style: TextStyle(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w600,
                                  fontSize: 16),
                            ),
                            SizedBox(
                              height: height * .5,
                            ),
                            Text(
                              '+' + '249927521696',
                              style: TextStyle(
                                  color: Colors.grey[600],
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14),
                            ),
                          ],
                        ),
                      ),
                    )),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Card(
                    margin: EdgeInsets.only(bottom: height * 2.5),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    elevation: 7,
                    child: Container(
                      width: width * 90,
                      height: height * 9,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(width: width* 3,),
                              ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Container(
                                  width: 50,
                                  height: height * 7,
                                  color: Color(0xffffd3d3),
                                  child: Container(
                                    margin: EdgeInsets.only(right: 2),
                                      child: Icon(Icons.arrow_back_ios,size: 25,color: Colors.grey[600],)),
//                                  child: Image.asset(''),
                                ),
                              ),
                              SizedBox(width: width* 3,),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Text(
                                    'Logout',
                                    style: TextStyle(
                                        color: Colors.grey[800],
                                        fontWeight: FontWeight.w600,
                                        fontSize: 16),
                                  ),
                                ],
                              )
                            ],
                          ),
                        ],
                      ),
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
