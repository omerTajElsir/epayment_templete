import 'package:albalad_bank/pages/rigister/confirm_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class RigisterPage extends StatefulWidget {
  @override
  _RigisterPageState createState() => _RigisterPageState();
}

class _RigisterPageState extends State<RigisterPage> {
  get sizebox => SizedBox(
        height: 40,
      );

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    final _phoneNumber = TextEditingController();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(children: <Widget>[
            Container(
              width: size.width,
              height: size.height / 2,
              child: Image.asset(
                'assets/login/Login.png',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              padding: EdgeInsets.all(30),
              child: Column(
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Text('Welcome to '),
                      Text(
                        'AL-BALAD BANK',
                        style:
                            TextStyle(color: Color(0xffDBA14F), fontSize: 20),
                      )
                    ],
                  ),
                  sizebox,
                  TextFormField(
                    controller: _phoneNumber,
                    inputFormatters: <TextInputFormatter>[
                      WhitelistingTextInputFormatter.digitsOnly
                    ],
                    style: TextStyle(decoration: TextDecoration.none),
                    decoration: const InputDecoration(
                        filled: true,
                        labelText: 'Enter your number',
                        icon: Text('+249')),
                  ),
                  sizebox,
                  ButtonTheme(
                    minWidth: size.width,
                    height: 50,
                    child: RaisedButton(
                      onPressed: () =>
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (context) => ConfirmPage(
                                    phoneNumber: _phoneNumber.text,
                                  ))),
                      child: Text(
                        'Login',
                        style: TextStyle(color: Colors.white),
                      ),
                      color: Colors.black,
                    ),
                  ),
                  Container(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text('Our'),
                      FlatButton(
                          onPressed: () {},
                          child: Text(
                            'T&C',
                            style: TextStyle(color: Color(0xffDBA14F)),
                          )),
                    ],
                  ))
                ],
              ),
            )
            // sizebox,
          ]),
        ),
      ),
    );
  }
}
