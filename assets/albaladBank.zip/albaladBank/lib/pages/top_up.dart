import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TopUp extends StatefulWidget {
  @override
  _TopUpState createState() => _TopUpState();
}

class _TopUpState extends State<TopUp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      child: Row(
                        children: <Widget>[
                          Container(
                            margin: EdgeInsets.only(top: 3),
                              child: IconButton(
                                  icon: Icon(
                                    Icons.arrow_back_ios,
                                    size: 20,
                                    color: Colors.grey[800],
                                  ),
                                  onPressed: null)),
                          Container(
                              child: Text(
                            'Top Up',
                            style: TextStyle(
                                color: Colors.grey[800],
                                fontSize: 20,
                                fontWeight: FontWeight.w600),
                          ))
                        ],
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.only(top: 3),
                        child: IconButton(
                            icon: Icon(
                              Icons.menu,
                              size: 25,
                              color: Colors.grey[800],
                            ),
                            onPressed: null)),
                  ],
                ),
              ),
              SizedBox(height: 30,),
              Container(
                margin: EdgeInsets.only(left: 25,right: 30),
                child: Text('Select Operator',style: TextStyle(color: Colors.grey[700],fontSize: 20),),
              ),
              SizedBox(height: 20,),
              Container(
                height: 100,
                margin: EdgeInsets.only(left: 10,right: 10),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Container(
                        margin:EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xffFFDB1C),
                        ),
                        child: Center(
                          child: Image.asset('assets/mtn.png'),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin:EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xffF26532),
                        ),
                        child: Center(
                          child: Image.asset('assets/canar.png'),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin:EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xff000207),
                        ),
                        child: Center(
                          child: Image.asset('assets/zain.png'),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Container(
                        margin:EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Color(0xff0074C8),
                        ),
                        child: Center(
                          child: Image.asset('assets/sudani.png'),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20,),
              Container(
                margin: EdgeInsets.only(left: 25,right: 30),
                child: TextField(
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    labelText: 'Phone No.',
                    labelStyle: TextStyle(color: Colors.grey[700]),
                    focusedBorder:UnderlineInputBorder(
                      borderSide: const BorderSide(color: Colors.black, width: 2.0),
                    ),
                    prefixText:  '+249 ',
                    prefixStyle: TextStyle(fontSize: 14)
                  ),
                  style: TextStyle(fontSize: 14),
                  cursorColor: Colors.grey[700],
                ),
              ),
              SizedBox(height: 5,),
              Container(
                margin: EdgeInsets.only(left: 25,right: 30),
                child: TextField(
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                      labelText: 'Amount',
                      labelStyle: TextStyle(color: Colors.grey[700]),
                      focusedBorder:UnderlineInputBorder(
                        borderSide: const BorderSide(color: Colors.black, width: 2.0),
                      ),
                  ),
                  style: TextStyle(fontSize: 14),
                  cursorColor: Colors.grey[700],
                ),
              ),
              SizedBox(height: 40,),
              Container(
                height: 50,
                decoration: BoxDecoration(
                  color: Color(0xff161616),
                  borderRadius: BorderRadius.circular(10)
                ),
                margin: EdgeInsets.only(left: 20,right: 20),
                child: Center(
                  child: Text('Pay',style: TextStyle(color: Colors.grey[100],fontSize: 22,fontWeight: FontWeight.w600),),
                )
              ),
            ],
          ),
        ),
      ),
    );
  }
}
