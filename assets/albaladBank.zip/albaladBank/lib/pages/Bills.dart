import 'package:flutter/material.dart';

class Bills extends StatefulWidget {
  @override
  _BillsState createState() => _BillsState();
}

class _BillsState extends State<Bills> {
  _billRow(BuildContext context, int index) {
    return Container(
      margin: EdgeInsets.only(left: 10,bottom: 5),
      child: Row(
        children: <Widget>[
          Card(
            elevation: 4,
            child: Container(
              height: 70,
              width: 70,
              child: Center(
                child: Image.asset('assets/haji.png'),
              ),
            ),
          ),
          SizedBox(
            width: 10,
          ),
          Container(
            margin: EdgeInsets.only(left: 5),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('Haji',style: TextStyle(color: Colors.grey[900],fontSize: 18,fontWeight: FontWeight.w600),),
                  SizedBox(height: 10,),
                  Text('Haji Services',style: TextStyle(color: Colors.grey[700],fontSize: 15,fontWeight: FontWeight.w500),),
                ],
              )
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      child: Row(
                        children: <Widget>[
                          Container(
                              margin: EdgeInsets.only(top: 3),
                              child: IconButton(
                                  icon: Icon(
                                    Icons.arrow_back_ios,
                                    size: 20,
                                    color: Colors.grey[800],
                                  ),
                                  onPressed: null)),
                          Container(
                              child: Text(
                            'Bills',
                            style: TextStyle(
                                color: Colors.grey[800],
                                fontSize: 20,
                                fontWeight: FontWeight.w600),
                          ))
                        ],
                      ),
                    ),
                    Container(
                        margin: EdgeInsets.only(top: 3),
                        child: IconButton(
                            icon: Icon(
                              Icons.menu,
                              size: 25,
                              color: Colors.grey[800],
                            ),
                            onPressed: null)),
                  ],
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                margin: EdgeInsets.only(left: 25, right: 30),
                child: Text(
                  'Our Available Payees List',
                  style: TextStyle(color: Colors.grey[700], fontSize: 20),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                    itemBuilder: (context,index) => _billRow(context, index),
                    itemCount: 10,
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
