import 'package:flutter/material.dart';

class PaymentSuccess extends StatefulWidget {
  @override
  _PaymentSuccessState createState() => _PaymentSuccessState();
}

class _PaymentSuccessState extends State<PaymentSuccess> {
  var width, height;
  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width / 100;
    height = MediaQuery.of(context).size.height / 100;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: Color(0xffECA432),
        body: SafeArea(
          child: Stack(
            children: <Widget>[
              Center(
                child: Container(
                  margin: EdgeInsets.only(top: height * 12),
                  child: Column(
                    children: <Widget>[
                      Text(
                        'Your Payment',
                        style: TextStyle(
                            color: Colors.grey[100],
                            fontSize: 18,
                            fontWeight: FontWeight.w500),
                      ),
                      Text(
                        'is Successful!',
                        style: TextStyle(
                            color: Colors.grey[100],
                            fontSize: 27,
                            fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                    height: height * 80,
                    margin: EdgeInsets.only(top: height * 25),
                    child: Stack(
                      children: <Widget>[
                        Container(
                            height: height * 60,
                            child: Image.asset(
                              'assets/CardBox.png',
                              fit: BoxFit.fill,
                            )),
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            margin: EdgeInsets.only(top: height * 11),
                            child: Column(
                              children: <Widget>[
                                Text(
                                  'Top Up No.',
                                  style: TextStyle(
                                      color: Colors.grey[700],
                                      fontSize: 12,
                                      fontWeight: FontWeight.w500),
                                ),
                                SizedBox(
                                  height: height * 1.2,
                                ),
                                Center(
                                  child: Container(
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: <Widget>[
                                        Text(
                                          '4235',
                                          style: TextStyle(
                                              color: Colors.grey[700],
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900),
                                        ),
                                        SizedBox(
                                          width: 8,
                                        ),
                                        Text(
                                          '4235',
                                          style: TextStyle(
                                              color: Colors.grey[700],
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900),
                                        ),
                                        SizedBox(
                                          width: 8,
                                        ),
                                        Text(
                                          '4235',
                                          style: TextStyle(
                                              color: Colors.grey[700],
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900),
                                        ),
                                        SizedBox(
                                          width: 8,
                                        ),
                                        Text(
                                          '4235',
                                          style: TextStyle(
                                              color: Colors.grey[700],
                                              fontSize: 17,
                                              fontWeight: FontWeight.w900),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: height * 3,
                                ),
                                Container(
                                  width: width * 63,
                                  child: Image.asset('assets/dividerCard.png'),
                                ),
                                Container(
                                  height: height * 27.7,
                                  width: width* 72.7,
                                  child: Row(
                                    children: <Widget>[
                                      Expanded(
                                        child: Container(
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                margin: EdgeInsets.only(left: width * 6,top: height * 4),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Text('Date',style: TextStyle(color: Colors.grey[500],fontWeight: FontWeight.w500,fontSize: 16),),
                                                    SizedBox(height: height * 1,),
                                                    Text('3-2-2020',style: TextStyle(color: Colors.grey[700],fontWeight: FontWeight.w500,fontSize: 17),),
                                                    SizedBox(height: height * 1,),
                                                    Text('Phone No',style: TextStyle(color: Colors.grey[500],fontWeight: FontWeight.w500,fontSize: 16),),
                                                    SizedBox(height: height * 1,),
                                                    Text('0927521696',style: TextStyle(color: Colors.grey[700],fontWeight: FontWeight.w500,fontSize: 17),),
                                                  ],
                                                ),
                                              ),
                                              SizedBox(height: height * 3,),
                                              Container(
                                                  margin: EdgeInsets.only(left: width * 6,top: height * 1),
                                                  child: Text('Top Up Amount',style: TextStyle(color: Colors.grey[500],fontWeight: FontWeight.w500,fontSize: 18),)
                                              ),

                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: Container(
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: <Widget>[
                                              Container(
                                                margin: EdgeInsets.only(left: width * 5,top: height * 4),
                                                child: Column(
                                                  mainAxisAlignment: MainAxisAlignment.start,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    Text('Time',style: TextStyle(color: Colors.grey[500],fontWeight: FontWeight.w500,fontSize: 16),),
                                                    SizedBox(height: height * 1,),
                                                    Text('10:00:00',style: TextStyle(color: Colors.grey[700],fontWeight: FontWeight.w500,fontSize: 17),),
                                                    SizedBox(height: height * 1,),
                                                    Text('Card No',style: TextStyle(color: Colors.grey[500],fontWeight: FontWeight.w500,fontSize: 16),),
                                                    SizedBox(height: height * 1,),
                                                    Text('234321234567',style: TextStyle(color: Colors.grey[700],fontWeight: FontWeight.w500,fontSize: 17),),
                                                  ],
                                                ),
                                              ),
                                              SizedBox(height: height * 1,),
                                              Container(
                                                  margin: EdgeInsets.only(left: width * 4),
                                                  child: Column(
                                                    children: <Widget>[
                                                      Container(
                                                        margin:EdgeInsets.only(right: width * 5),
                                                        child: Divider(
                                                          color: Color(0xff979797),
                                                          thickness: 2,
                                                        ),
                                                      ),
                                                      SizedBox(height: height * .5,),
                                                      Container(
                                                        margin: EdgeInsets.only(right: width * 5),
                                                          child: Text('200 SDG',style: TextStyle(color: Colors.grey[500],fontWeight: FontWeight.w900,fontSize: 23),)),
                                                    ],
                                                  )
                                              ),

                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        )
                      ],
                    )),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Container(
                  height: 75,
                  width: 75,
                  margin: EdgeInsets.only(top: height * 24),
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Color(0xffECA432),
                      border: Border.all(color: Colors.grey[100], width: 4)),
                  child: Icon(
                    Icons.check,
                    size: 50,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
