import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class Maps extends StatefulWidget {
  @override
  _MapsState createState() => _MapsState();
}

class _MapsState extends State<Maps> {

  GoogleMapController mapController;

  final LatLng _center = const LatLng(45.521563, -122.677433);

  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Card(
                elevation: 1,
                margin: EdgeInsets.all(0),
                child: Container(
                  color: Colors.white,
                  height: 50,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(
                        child: Row(
                          children: <Widget>[
                            Container(
                                margin: EdgeInsets.only(top: 3),
                                child: IconButton(
                                    icon: Icon(
                                      Icons.arrow_back_ios,
                                      size: 35,
                                      color: Colors.grey[800],
                                    ),
                                    onPressed: null)),
                            SizedBox(width: 10,),
                            Container(
                                margin: EdgeInsets.only(top: 5),
                                child: Text(
                                  'November',
                                  style: TextStyle(
                                      color: Colors.grey[800],
                                      fontSize: 22,
                                      fontWeight: FontWeight.w600),
                                )),

                          ],
                        ),
                      ),
                      Container(
                          margin: EdgeInsets.only(top: 3),
                          child: Row(
                            children: <Widget>[
                              IconButton(
                                  icon: Icon(
                                    Icons.location_on,
                                    size: 23,
                                    color: Colors.grey[700],
                                  ),
                                  onPressed: (){}
                              ),
                              SizedBox(width: 10,),
                              IconButton(
                                  icon: Icon(
                                    Icons.menu,
                                    size: 23,
                                    color: Colors.grey[700],
                                  ),
                                  onPressed: (){}
                              ),
                            ],
                          )
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
        ),
      ),
    );
  }
}
