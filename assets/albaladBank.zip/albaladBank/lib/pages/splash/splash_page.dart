import 'dart:async';

import 'package:albalad_bank/pages/tab/tab_page.dart';
import 'package:flutter/material.dart';

class SplashPage extends StatefulWidget {
  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    Timer(
        Duration(seconds: 3),
        () => Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => TabPage())));
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Container(
        child: Image.asset(
          'assets/splash/splash.png', height: size.height,
          width: size.width,
          alignment: Alignment.center,
          fit: BoxFit.fill,
        ),
      ),
    );
  }
}
