import 'package:albalad_bank/pages/maps.dart';
import 'package:albalad_bank/pages/month_report.dart';
import 'package:albalad_bank/pages/electricity.dart';
import 'package:albalad_bank/pages/Bills.dart';
import 'package:albalad_bank/pages/payment_success.dart';
import 'package:albalad_bank/pages/splash/splash_page.dart';
import 'package:albalad_bank/pages/top_up.dart';
import 'package:albalad_bank/pages/transactions.dart';
import 'package:albalad_bank/pages/tab/profile.dart';
import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Albalad Bank',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Maps();
  }
}


